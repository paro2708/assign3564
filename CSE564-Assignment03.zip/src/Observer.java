public interface Observer {
		public abstract void update(int points[]);
}
