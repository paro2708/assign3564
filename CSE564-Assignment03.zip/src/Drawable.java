import javax.swing.JPanel;

interface Drawable {
    public JPanel plotPoints(JPanel jpanel);
}